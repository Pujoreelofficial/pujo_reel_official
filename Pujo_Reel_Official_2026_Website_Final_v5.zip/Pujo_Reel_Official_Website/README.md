# Pujo Reel Official — 2026

Static, responsive Pujo Reel Official website for the 2026 Durga Puja season.

## Included
- Pujo Reel Official branding and supplied logo
- Local festival video asset
- Durgapur and Kolkata pandal sections
- Supplied 2026 themes shown as **সেরা থিম** with the matching **LANDMARK**
- No Google Maps UI or route/map functionality
- The supplied Puja song is embedded inside the Music section using the provided YouTube source; no visible YouTube URL/button is shown
- Liquid-glass responsive UI

## Publish
Upload the contents of `Pujo_Reel_Official_Website` to GitHub Pages or another static host.
