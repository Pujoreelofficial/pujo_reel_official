// Pujo Reel Official — 2026 pandal guide

const pandals = {
  durgapur: [
    {
      name: "Benachity High School Ground",
      area: "Agrani Lane, Benachity, Durgapur",
      theme: "Recreating a spectacular 140-foot tall BAPS Swaminarayan Akshardham Temple (USA).",
      location: "Located at the Benachity High School Ground along the Agrani Lane shopping stretch."
    },
    {
      name: "Marconi Dakshin Pally",
      area: "Marconi Avenue, B-Zone, Durgapur",
      theme: "Recreating the magnificent architecture of the BAPS Hindu Mandir in Abu Dhabi.",
      location: "Situated inside Marconi Avenue, B-Zone township area."
    },
    {
      name: "Chaturanga Sarbojonin Durga Puja",
      area: "City Centre, Durgapur",
      theme: "Recreating the highly intricate Vrindavan Prem Mandir theme.",
      location: "Sprawled over the Chaturanga Puja Maidan in the heart of City Centre, right near the primary commercial hub."
    },
    {
      name: "Khudiram Math Durga Puja",
      area: "Benachity, Durgapur",
      theme: "A grand-scale installation of the Ayodhya Ram Mandir.",
      location: "Built at Khudiram Math ground, located in the Benachity sector."
    },
    {
      name: "Shankarpur Sarbojonin",
      area: "Shankarpur, Durgapur",
      theme: "An innovative Shri Krishna Dwarka Nagri concept with simulated underwater graphics/vibe.",
      location: "Set up at the central community grounds in the Shankarpur residential zone."
    },
    {
      name: "Sector 2C Puja Ground",
      area: "Sector 2C, Durgapur",
      theme: "2026 Durga Puja theme and pandal presentation.",
      location: "Sector 2C Puja Ground, Durgapur."
    }
  ],
  kolkata: [
    {
      name: "Santosh Mitra Square",
      area: "Bowbazar, Central Kolkata",
      theme: "A grand patriotic tribute celebrating \"Vande Mataram\" to honor the 150th anniversary of the national song.",
      location: "Built at the Santosh Mitra Square ground in Bowbazar.",
      transit: "Easiest transit: Sealdah Metro Station (Green Line) or Central Metro Station (Blue Line)."
    },
    {
      name: "Sealdah Railway Athletic Club",
      area: "Sealdah, Central Kolkata",
      theme: "A magnificent architectural replica of London's iconic London Bridge.",
      location: "Situated directly in the Sealdah Station zone, near Netaji Subhas Ground, 1 Kaiser Street.",
      transit: "Convenient first stop when entering central Kolkata via Sealdah railway station."
    },
    {
      name: "Tala Prattoy",
      area: "Tala, North Kolkata",
      theme: "\"Biyojon\" (Separation) — an art-centric, emotional concept focusing on the concept of letting go.",
      location: "Located in Tala, North Kolkata.",
      transit: "Closest transit hub: Shambazar Metro Station."
    },
    {
      name: "Kumartuli Park",
      area: "Kumartuli, North Kolkata",
      theme: "\"O Ganga Tumi Boichho Keno\" — a localized tribute highlighting the river Ganga's historical and cultural connection to Kolkata.",
      location: "In the heart of the idol-makers' neighborhood at Kumartuli Park, 8B Abhay Mitra Street.",
      transit: "Short walk from Sovabazar Sutanuti Metro Station."
    },
    {
      name: "Suruchi Sangha",
      area: "New Alipore, South Kolkata",
      theme: "\"Utsho\" (The Source) — a concept-heavy, highly artistic environment exploring origin stories.",
      location: "500 and 505, Station Road, New Alipore.",
      transit: "About 350 metres from New Alipore Railway Station."
    },
    {
      name: "Samaj Sebi Sangha",
      area: "Ballygunge / Lake Market, South Kolkata",
      theme: "\"Uttam Kumar at 100\" — celebrating the birth centenary with artwork showcasing all 208 of his films.",
      location: "Set up near Lake Market in South Kolkata.",
      transit: "Quick walk from Kalighat Metro Station."
    }
  ]
};

const themeGrid = document.getElementById("theme-grid");

function renderThemeHighlights() {
  const all = [
    ...pandals.durgapur.map(item => ({...item, city: "দুর্গাপুর"})),
    ...pandals.kolkata.map(item => ({...item, city: "কলকাতা"}))
  ];
  themeGrid.innerHTML = all.map((item, index) => `
    <article class="theme-card glass-panel">
      <span class="theme-city glass">${item.city}</span>
      <span class="theme-label">${String(index + 1).padStart(2, "0")} · LANDMARK</span>
      <h3>${item.name}</h3>
      <div>
        <span class="theme-label">সেরা থিম</span>
        <p>${item.theme}</p>
      </div>
      <div class="theme-landmark">
        <span class="theme-label">LANDMARK</span>
        <p>${item.location}</p>
      </div>
    </article>
  `).join("");
}

const list = document.getElementById("pandal-list");
const tabs = document.querySelectorAll(".city-tab");
const cityTitle = document.getElementById("cityTitle");
const citySubtitle = document.getElementById("citySubtitle");

function renderPandals(city) {
  const items = pandals[city];
  const isDurgapur = city === "durgapur";
  cityTitle.textContent = isDurgapur ? "দুর্গাপুর" : "কলকাতা";
  citySubtitle.textContent = isDurgapur
    ? "Major 2026 Pandals — Themes & Locations"
    : "Central, North & South Kolkata — 2026 Themes & Locations";

  list.innerHTML = items.map((item, index) => `
    <article class="pandal-card glass-panel">
      <div class="pandal-number">${String(index + 1).padStart(2, "0")}</div>
      <div class="pandal-content">
        <div class="pandal-topline">
          <span class="city-chip">${isDurgapur ? "DURGAPUR" : "KOLKATA"}</span>
          <span class="area-chip">${item.area}</span>
        </div>
        <h3>${item.name}</h3>
        <div class="pandal-detail">
          <span class="detail-label">সেরা থিম</span>
          <p>${item.theme}</p>
        </div>
        <div class="pandal-detail location-detail">
          <span class="detail-label">LANDMARK</span>
          <p>${item.location}</p>
        </div>
        ${item.transit ? `<div class="pandal-detail transit-detail"><span class="detail-label">যাতায়াত</span><p>${item.transit}</p></div>` : ""}
      </div>
    </article>
  `).join("");
}

tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.toggle("active", t === tab));
    renderPandals(tab.dataset.city);
  });
});

renderPandals("durgapur");



renderThemeHighlights();
